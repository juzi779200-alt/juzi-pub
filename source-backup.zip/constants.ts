import { BankDetails, Product } from './types';

export const CONTACT_INFO = {
  whatsapp: "+86 15884907792",
  email1: "lockboxshop@gmail.com",
  email2: "lockboxshop@gmail.com"
};

export const BANK_INFO: BankDetails = {
  beneficiary: "GUOYA",
  address: "Daliang Village, Guange Town, Qianfeng District, Guang'an City, Sichuan Province",
  city: "Guang'an",
  province: "Sichuan",
  country: "China",
  accountNumber: "6217007200103510130",
  swiftCode: "PCBCCNBJSZX",
  bankName: "China Construction Bank"
};

export const PRODUCTS: Product[] = [
  {
    id: "p1",
    title: {
      en: "SpongeBob Lucky Box",
      zh: "海绵宝宝幸运盒子",
      es: "Caja de la Suerte Bob Esponja"
    },
    price: 79.00,
    originalPrice: 129.00,
    description: {
      en: "A SpongeBob-themed surprise lucky box! Each box includes 15 cute gifts—from cozy plushies, stationery, and accessories to heartwarming surprises. Every box is unique with random items. Ships within 5–10 days after purchase. Perfect for yourself, friends, or kids.",
      zh: "以海绵宝宝为主题的惊喜幸运盒子！每个盒子都有15个可爱礼物，从舒适的毛绒玩具、文具、配饰到暖心的小惊喜，应有尽有，每个盒子都独一无二，里面的礼物都是随机的，下单之后就5-10天发货。不管是给自己还是送朋友还是送给自己的孩子，都是一份不错的礼物。",
      es: "¡Caja de la suerte sorpresa temática de Bob Esponja! Cada caja incluye 15 regalos lindos: peluches acogedores, papelería y accesorios, además de pequeñas sorpresas. Cada caja es única con artículos aleatorios. Envío dentro de 5–10 días tras la compra. Ideal para ti, tus amigos o niños."
    },
    images: [
      "/Luckboxshop/images/01.jpg", 
      "/Luckboxshop/images/01.jpg"
    ],
    tags: [
        { en: "Popular", zh: "热门", es: "Popular" }, 
        { en: "Storage", zh: "收纳", es: "Almacenaje" }
    ],
    reviews: 156,
    rating: 5.0
  },
  {
    id: "p8",
    title: {
      en: "Judy Hopps Lock Box",
      zh: "朱迪霍普斯 Lock Box",
      es: "Lock Box Judy Hopps"
    },
    price: 89.00,
    description: {
      en: "A Judy Hopps-themed surprise lucky box! Each box includes 15 cute gifts—from plushies, stationery, and accessories to delightful surprises. Every box is unique with random items. Ships within 5–10 days after purchase. Perfect for yourself, friends, or kids.",
      zh: "以《疯狂动物城》的朱迪霍普斯为主题的幸运盒子，每个盒子都有15个可爱礼物，从舒适的毛绒玩具、文具、配饰到暖心的小惊喜，应有尽有，每个盒子都独一无二，里面的礼物都是随机的，下单之后就5-10天发货。不管是给自己还是送朋友还是送给自己的孩子，都是一份不错的礼物。",
      es: "¡Caja de la suerte sorpresa temática de Judy Hopps! Cada caja incluye 15 regalos lindos: peluches, papelería y accesorios, además de pequeñas sorpresas. Cada caja es única con artículos aleatorios. Envío dentro de 5–10 días tras la compra. Ideal para ti, tus amigos o niños."
    },
    images: [
      "/Luckboxshop/images/11.jpg",
      "/Luckboxshop/images/11.jpg"
    ],
    tags: [
        { en: "Disney", zh: "迪士尼", es: "Disney" }, 
        { en: "Lock Box", zh: "锁盒", es: "Lock Box" }
    ],
    reviews: 0,
    rating: 5.0
  },
  {
    id: "p9",
    title: {
      en: "Nick Wilde Lock Box",
      zh: "尼克王尔德 Lock Box",
      es: "Lock Box Nick Wilde"
    },
    price: 89.00,
    description: {
      en: "A Nick Wilde-themed surprise lucky box! Each box includes 15 cute gifts—from plushies, stationery, and accessories to delightful surprises. Every box is unique with random items. Ships within 5–10 days after purchase. Perfect for yourself, friends, or kids.",
      zh: "以《疯狂动物城》的尼克王尔德为主题的幸运盒子。每个盒子都有15个可爱礼物，从舒适的毛绒玩具、文具、配饰到暖心的小惊喜，应有尽有，每个盒子都独一无二，里面的礼物都是随机的，下单之后就5-10天发货。不管是给自己还是送朋友还是送给自己的孩子，都是一份不错的礼物。",
      es: "¡Caja de la suerte sorpresa temática de Nick Wilde! Cada caja incluye 15 regalos lindos: peluches, papelería y accesorios, además de pequeñas sorpresas. Cada caja es única con artículos aleatorios. Envío dentro de 5–10 días tras la compra. Ideal para ti, tus amigos o niños."
    },
    images: [
      "/Luckboxshop/images/12.jpg",
      "/Luckboxshop/images/12.jpg"
    ],
    tags: [
        { en: "Disney", zh: "迪士尼", es: "Disney" }, 
        { en: "Luck Box", zh: "锁盒", es: "Luck Box" }
    ],
    reviews: 0,
    rating: 5.0
  },
  {
    id: "p2",
    title: {
      en: "New Year Lucky Box",
      zh: "新年 Lucky Box",
      es: "Caja de la Suerte de Año Nuevo"
    },
    price: 79.00,
    description: {
      en: "Start the year with a New Year-themed surprise lucky box! Each box includes 15 cute gifts—from plushies, stationery, and accessories to festive surprises. Every box is unique with random items. Ships within 5–10 days after purchase. Perfect for yourself, friends, or kids.",
      zh: "以新年为主幸运盒子，每个盒子都有15个可爱礼物，从舒适的毛绒玩具、文具、配饰到暖心的小惊喜，应有尽有，每个盒子都独一无二，里面的礼物都是随机的，下单之后就5-10天发货。不管是给自己还是送朋友还是送给自己的孩子，都是一份不错的礼物。",
      es: "¡Empieza el año con una caja de la suerte temática de Año Nuevo! Cada caja incluye 15 regalos lindos: peluches, papelería y accesorios, además de sorpresas festivas. Cada caja es única con artículos aleatorios. Envío dentro de 5–10 días tras la compra. Ideal para ti, tus amigos o niños."
    },
    images: [
      "/Luckboxshop/images/02.jpg",
      "/Luckboxshop/images/02.jpg"
    ],
    tags: [
        { en: "New Year", zh: "新年", es: "Año Nuevo" }, 
        { en: "Lucky", zh: "幸运", es: "Suerte" }
    ],
    reviews: 203,
    rating: 4.9
  },
  {
    id: "p3",
    title: {
      en: "Stitch Lucky Box",
      zh: "史迪奇 Lucky Box",
      es: "Caja de la Suerte Stitch"
    },
    price: 79.00,
    description: {
      en: "A Stitch-themed surprise lucky box! Each box includes 15 cute gifts—from plushies, stationery, and accessories to heartwarming surprises. Every box is unique with random items. Ships within 5–10 days after purchase. Perfect for yourself, friends, or kids.",
      zh: "以调皮的史迪奇为主题的惊喜幸运盒子！每个盒子都有15个可爱礼物，从舒适的毛绒玩具、文具、配饰到暖心的小惊喜，应有尽有，每个盒子都独一无二，里面的礼物都是随机的，下单之后就5-10天发货。不管是给自己还是送朋友还是送给自己的孩子，都是一份不错的礼物。",
      es: "¡Caja de la suerte sorpresa temática de Stitch! Cada caja incluye 15 regalos lindos: peluches, papelería y accesorios, además de pequeñas sorpresas. Cada caja es única con artículos aleatorios. Envío dentro de 5–10 días tras la compra. Ideal para ti, tus amigos o niños."
    },
    images: [
      "/Luckboxshop/images/03.jpg",
      "/Luckboxshop/images/03.jpg"
    ],
    tags: [
        { en: "Disney", zh: "迪士尼", es: "Disney" }, 
        { en: "Lucky", zh: "幸运", es: "Suerte" }
    ],
    reviews: 89,
    rating: 4.8
  },
  {
    id: "p4",
    title: {
      en: "Hello Kitty Lucky Box",
      zh: "Hello Kitty Lucky Box",
      es: "Caja de la Suerte Hello Kitty"
    },
    price: 79.00,
    description: {
      en: "A Hello Kitty-themed surprise lucky box! Each box includes 15 cute gifts—from plushies, stationery, and accessories to heartwarming surprises. Every box is unique with random items. Ships within 5–10 days after purchase. Perfect for yourself, friends, or kids.",
      zh: "以可爱的 Hello Kitty 为主题的幸运盒子！每个盒子都有15个可爱礼物，从舒适的毛绒玩具、文具、配饰到暖心的小惊喜，应有尽有，每个盒子都独一无二，里面的礼物都是随机的，下单之后就5-10天发货。不管是给自己还是送朋友还是送给自己的孩子，都是一份不错的礼物。",
      es: "¡Caja de la suerte sorpresa temática de Hello Kitty! Cada caja incluye 15 regalos lindos: peluches, papelería y accesorios, además de pequeñas sorpresas. Cada caja es única con artículos aleatorios. Envío dentro de 5–10 días tras la compra. Ideal para ti, tus amigos o niños."
    },
    images: [
      "/Luckboxshop/images/04.jpg",
      "/Luckboxshop/images/04.jpg"
    ],
    tags: [
        { en: "Sanrio", zh: "三丽鸥", es: "Sanrio" }, 
        { en: "Lucky", zh: "幸运", es: "Suerte" }
    ],
    reviews: 412,
    rating: 4.9
  },
  {
    id: "p5",
    title: {
      en: "Kuromi Lucky Box",
      zh: "库洛米 Lucky Box",
      es: "Caja de la Suerte Kuromi"
    },
    price: 79.00,
    description: {
      en: "A Kuromi-themed surprise lucky box! Each box includes 15 cute gifts—from plushies, stationery, and accessories to heartwarming surprises. Every box is unique with random items. Ships within 5–10 days after purchase. Perfect for yourself, friends, or kids.",
      zh: "以古灵精怪的库洛米为主题的惊喜幸运盒子！每个盒子都有15个可爱礼物，从舒适的毛绒玩具、文具、配饰到暖心的小惊喜，应有尽有，每个盒子都独一无二，里面的礼物都是随机的，下单之后就5-10天发货。不管是给自己还是送朋友还是送给自己的孩子，都是一份不错的礼物。",
      es: "¡Caja de la suerte sorpresa temática de Kuromi! Cada caja incluye 15 regalos lindos: peluches, papelería y accesorios, además de pequeñas sorpresas. Cada caja es única con artículos aleatorios. Envío dentro de 5–10 días tras la compra. Ideal para ti, tus amigos o niños."
    },
    images: [
      "/Luckboxshop/images/05.jpg",
      "/Luckboxshop/images/05.jpg"
    ],
    tags: [
        { en: "Sanrio", zh: "三丽鸥", es: "Sanrio" }, 
        { en: "Lucky", zh: "幸运", es: "Suerte" }
    ],
    reviews: 95,
    rating: 4.7
  },
  {
    id: "p6",
    title: {
      en: "Strawberry Bear Lucky Box",
      zh: "草莓熊 Lucky Box",
      es: "Caja de la Suerte Oso Fresa"
    },
    price: 79.00,
    description: {
      en: "A Strawberry Bear-themed surprise lucky box! Each box includes 15 cute gifts—from plushies, stationery, and accessories to heartwarming surprises. Every box is unique with random items. Ships within 5–10 days after purchase. Perfect for yourself, friends, or kids.",
      zh: "以甜美的草莓熊为主题的惊喜幸运盒子！每个盒子都有15个可爱礼物，从舒适的毛绒玩具、文具、配饰到暖心的小惊喜，应有尽有，每个盒子都独一无二，里面的礼物都是随机的，下单之后就5-10天发货。不管是给自己还是送朋友还是送给自己的孩子，都是一份不错的礼物。",
      es: "¡Caja de la suerte sorpresa temática de Oso Fresa! Cada caja incluye 15 regalos lindos: peluches, papelería y accesorios, además de pequeñas sorpresas. Cada caja es única con artículos aleatorios. Envío dentro de 5–10 días tras la compra. Ideal para ti, tus amigos o niños."
    },
    images: [
      "/Luckboxshop/images/06.jpg",
      "/Luckboxshop/images/06.jpg"
    ],
    tags: [
        { en: "Disney", zh: "迪士尼", es: "Disney" }, 
        { en: "Lucky", zh: "幸运", es: "Suerte" }
    ],
    reviews: 110,
    rating: 4.8
  },
  {
    id: "p7",
    title: {
      en: "Cinnamoroll Lucky Box",
      zh: "玉桂狗幸运盒子",
      es: "Caja de la Suerte Cinnamoroll"
    },
    price: 79.00,
    description: {
      en: "A Cinnamoroll-themed surprise lucky box! Each box includes 15 cute gifts—from plushies, stationery, and accessories to heartwarming surprises. Every box is unique with random items. Ships within 5–10 days after purchase. Perfect for yourself, friends, or kids.",
      zh: "以可爱的玉桂狗为主题的惊喜幸运盒子！每个盒子都有15个可爱礼物，从舒适的毛绒玩具、文具、配饰到暖心的小惊喜，应有尽有，每个盒子都独一无二，里面的礼物都是随机的，下单之后就5-10天发货。不管是给自己还是送朋友还是送给自己的孩子，都是一份不错的礼物。",
      es: "¡Caja de la suerte sorpresa temática de Cinnamoroll! Cada caja incluye 15 regalos lindos: peluches, papelería y accesorios, además de pequeñas sorpresas. Cada caja es única con artículos aleatorios. Envío dentro de 5–10 días tras la compra. Ideal para ti, tus amigos o niños."
    },
    images: [
      "/Luckboxshop/images/10.jpg",
      "/Luckboxshop/images/10.jpg"
    ],
    tags: [
        { en: "Sanrio", zh: "三丽鸥", es: "Sanrio" }, 
        { en: "Lucky", zh: "幸运", es: "Suerte" }
    ],
    reviews: 67,
    rating: 4.9
  },
  {
    id: "p10",
    title: {
      en: "Winnie the Pooh Lucky Box",
      zh: "小熊维尼 Lucky Box",
      es: "Caja de la Suerte Winnie the Pooh"
    },
    price: 79.00,
    description: {
      en: "A Winnie the Pooh-themed surprise lucky box! Each box includes 15 cute gifts—from plushies, stationery, and accessories to heartwarming surprises. Every box is unique with random items. Ships within 5–10 days after purchase. Perfect for yourself, friends, or kids.",
      zh: "以小熊维尼为主题的惊喜幸运盒子！每个盒子都有15个可爱礼物，从舒适的毛绒玩具、文具、配饰到暖心的小惊喜，应有尽有。每个盒子都独一无二，礼物为随机组合。下单后 5–10 天内发货，送礼或自用都很合适。",
      es: "¡Caja de la suerte sorpresa temática de Winnie the Pooh! Cada caja incluye 15 regalos lindos: peluches, papelería y accesorios, además de pequeñas sorpresas. Cada caja es única con artículos aleatorios. Envío dentro de 5–10 días tras la compra. Ideal para ti, tus amigos o niños."
    },
    images: [
      "/Luckboxshop/images/13.jpg",
      "/Luckboxshop/images/13.jpg"
    ],
    tags: [
        { en: "Disney", zh: "迪士尼", es: "Disney" }, 
        { en: "Lucky", zh: "幸运", es: "Suerte" }
    ],
    reviews: 0,
    rating: 4.9
  },
  {
    id: "p11",
    title: {
      en: "Labubu Lucky Box",
      zh: "拉布布幸运盒子",
      es: "Caja de la Suerte Labubu"
    },
    price: 79.00,
    description: {
      en: "A Labubu-themed surprise lucky box! Each box includes 15 cute gifts—from plushies, stationery, and accessories to delightful surprises. Every box is unique with random items. Ships within 5–10 days after purchase. Perfect for yourself, friends, or kids.",
      zh: "以拉布布为主题的惊喜幸运盒子！每个盒子都有15个可爱礼物，从毛绒、公仔、文具、配饰到暖心的小惊喜一应俱全。每个盒子都独一无二，礼物为随机组合。下单后 5–10 天内发货，送礼或自用都很合适。",
      es: "¡Caja de la suerte sorpresa temática de Labubu! Cada caja incluye 15 regalos lindos: peluches, papelería y accesorios, además de pequeñas sorpresas. Cada caja es única con artículos aleatorios. Envío dentro de 5–10 días tras la compra. Ideal para ti, tus amigos o niños."
    },
    images: [
      "/Luckboxshop/images/09.jpg",
      "/Luckboxshop/images/09.jpg"
    ],
    tags: [
        { en: "Popular", zh: "热门", es: "Popular" }, 
        { en: "Lucky", zh: "幸运", es: "Suerte" }
    ],
    reviews: 0,
    rating: 4.8
  }
];

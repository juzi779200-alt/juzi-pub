import React from 'react';
import { ShoppingBag, Eye } from 'lucide-react';
import { Product } from '../types';
import { useLanguage } from './LanguageContext';

interface ProductCardProps {
  product: Product;
  onClick: (id: string) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onClick }) => {
  const { language, t } = useLanguage();

  return (
    <div 
      className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 flex flex-col cursor-pointer"
      onClick={() => onClick(product.id)}
    >
      <div className="relative aspect-square overflow-hidden bg-gray-100">
        <img 
          src={product.images[0]} 
          alt={product.title[language]}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        {product.originalPrice && (
            <span className="absolute top-3 left-3 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                {t.product.sale}
            </span>
        )}
        
        {/* Hover Overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
            <button className="bg-white text-brand-dark px-6 py-2 rounded-full font-semibold shadow-lg transform translate-y-4 group-hover:translate-y-0 transition-transform flex items-center gap-2">
                <Eye size={18} /> {t.product.viewDetails}
            </button>
        </div>
      </div>
      
      <div className="p-5 flex-1 flex flex-col">
        <div className="text-xs text-brand-accent font-bold mb-1 uppercase tracking-wider">{product.tags[0][language]}</div>
        <h3 className="text-gray-800 font-bold text-lg mb-2 leading-tight group-hover:text-brand-accent transition-colors">
            {product.title[language]}
        </h3>
        <div className="mt-auto flex items-center justify-between">
            <div className="flex flex-col">
                <span className="text-xs text-gray-400">{t.product.price}</span>
                <span className="text-xl font-bold text-gray-900">${product.price.toFixed(2)}</span>
            </div>
            <div className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center text-gray-400 group-hover:bg-brand-accent group-hover:text-white transition-colors">
                <ShoppingBag size={18} />
            </div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
